v.1.0

Author: Empdoom (gamer profile)

Mod Name: Unlockable Navy Licenses

Mod Intent is to allow players legitimate access to the navy licenses and equipment currently unavailable without hostile action in game.
Without a navy campaign (something else I'm tinkering with) it's a little difficult to balance so currently once you unlock the first license just play through the story for the rest.

Possible reasons to not be seeing the licenses...

There is a reputation trigger with the republic to not be hostile for this to implement the first license unlock. You must also have received news about the secession.
This should trigger before you can officially join the free worlds but i did put it in as a requirement to not have joined because who would sell ships to their enemies?
So, it may conflict with preexisting saves.

At the current version I have only tested up until the first License unlock but will be actively working on this and other mods for some time yet.


Legal: 	1.By using or installing this mod you agree you cannot take legal action against the author in any way, shape, form and/or method.
		2.By using or installing this mod you agree to waive any and all legal rights you may have against the author.
		3.By using or installing this mod you agree that this legal statement is to be interpreted exactly as written.
		Any resembalance of anything in these files to anything else is purely coincidental and unintentional.
		
Disclaimer: This mod is created for the game Endless Sky see the following,
Copyright (c) 2014 by Michael Zahniser

Endless Sky is free software: you can redistribute it and/or modify it under the
terms of the GNU General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) any later version.

Endless Sky is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with
this program. If not, see <https://www.gnu.org/licenses/>.
		
		